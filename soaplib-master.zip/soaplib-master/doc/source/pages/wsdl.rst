WSDL API
========

The wsdl module provides an interface into dynamic WSDL generation.

WSDL
-----

.. automodule:: soaplib.core.wsdl
    :members:
    :undoc-members:
    :inherited-members: