
import sys

x = 2
y = x**2
sys.exit(y)
