
__all__ = ["foo"]

def bar():
    return 40

def foo():
    return bar() + 2
 
