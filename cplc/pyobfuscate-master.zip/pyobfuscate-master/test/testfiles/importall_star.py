from tobeimported_everything import *
import sys

sys.exit(one()+two()+thirtynine())

