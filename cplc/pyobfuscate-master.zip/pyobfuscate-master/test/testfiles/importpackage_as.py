import sys

from package.tobeimported import foo as bar

sys.exit(bar())
