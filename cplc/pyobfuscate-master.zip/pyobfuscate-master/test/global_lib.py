# Library for the globals test

external_global_top = "a"
external_global_ro = "b"
external_global_rw = "c"

