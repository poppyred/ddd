sum(i*i for i in range(10))

sum(x*y for x,y in zip(xvec, yvec))


